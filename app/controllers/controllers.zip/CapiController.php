<?php

class CapiController extends Controller {


	public function __construct() {
        $this->beforeFilter('csrf', array('on'=>'post'));
    }

    public function showCapiSE($nks,$page){
    	if($page==1){
    		$data= B1::find($nks);  		
    		return View::make('capi/capi-se-1')->with('data',$data);
    	}else if($page==2){	
	    	$data = B2::find($nks);
	    	return View::make('capi/capi-se-2')->with('data',$data);  
    	}
    	else if($page==3){	
	    	$data = B3::find($nks);
	    	return View::make('capi/capi-se-3')->with('data',$data);  
    	}
    	else if($page==4){	
	    	$data = B4::where('nks_b1','=',$nks)->paginate(10);
	    	return View::make('capi/capi-se-listkapal')->with('data',$data);  
    	}
    	else if($page==5){	
	    	$data = B4::find($nks);
	    	return View::make('capi/capi-se-4')->with('data',$data);  
    	}
    	else if($page==6){	
	    	$data = B4::find($nks);
	    	return View::make('capi/capi-se-5')->with('data',$data);  
    	}
        else if($page==7){  
            $data = B4::find($nks);
            return View::make('capi/capi-se-6')->with('data',$data);  
        }

        else if($page==8){  
            $data = B4::find($nks);
            return View::make('capi/capi-se-7')->with('data',$data);  
        }
        else if($page==9){  
            $data = B5::find($nks);
            return View::make('capi/capi-se-8')->with('data',$data);  
        }
        else if($page==10){  
            $data = B5::find($nks);
            return View::make('capi/capi-se-9')->with('data',$data);  
        }
        else if($page==11){  
            $data = B6::find($nks);
            return View::make('capi/capi-se-10')->with('data',$data);  
        }
    }

    public function showListCapiSE(){
        if(Input::get('NIM')!=null){
            $q = Input::get('NIM');
            $data = B2::where('b2r2s1','=',$q)->paginate(12);
            return View::make('capi/capi-se')->with('data',$data);
        }
        else{    
            if(Auth::user()->id_jabatan==3){
                $kortim = Kortim::where('user_id','=',Auth::user()->id)->first();
                $data = B2::where('b2r2s2','=',$kortim['nimkortim'])->paginate(12);
                return View::make('capi/capi-se')->with('data',$data);
            }else{
            	$data = B1::paginate(12);
            	return View::make('capi/capi-se')->with('data',$data);
            }
        }
    }

	public function showCapiSK(){

    }


}
