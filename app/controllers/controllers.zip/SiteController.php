<?php

class SiteController extends Controller {

	public function __construct() {
        $this->beforeFilter('csrf', array('on'=>'post'));
    }

	public function welcome(){
        $data['usaha'] = Progrec::where('kegiatan','=','CLEANING USAHA')->get();
        $data['pekerja'] = Progrec::where('kegiatan','=','CLEANING PEKERJA')->get();
        $data['user'] = Auth::user(); 
		return View::make('monitoring/index')->with('data',$data);
	}


        public function showRegister(){
        return View::make('monitoring/register');        
    }

    public function postRegister()
    {
        // Get all the inputs
        // id is used for login, username is used for validation to return correct error-strings
        $userdata = array(
            'username' => Input::get('username'),
            'email' => Input::get('email'),
            'idpkl' => Input::get('idpkl'),
            'password' => Input::get('password'),
            'jabatan' => Input::get('jabatan'),
            'bidang' => Input::get('bidang'),
            'password_confirmation' => Input::get('password_confirmation')
        );

        // Declare the rules for the form validation.
        $rules = array(
            'username'  => 'Required|min:2|unique:users',
            'email' => 'Required|email|unique:users',
            'idpkl' => 'Required',
            'password'  => 'Required|alpha_num|between:6,12|confirmed',
            'password_confirmation' => 'Required|alpha_num|between:6,12'
        );

        // Validate the inputs.
        $validator = Validator::make($userdata, $rules);

        // Check if the form validates with success.
        if ($validator->passes())
        {
            $user = new User;
            $user->username = Input::get('username');
            $user->email = Input::get('email');
            $user->password = Hash::make(Input::get('password'));
            $user->id_bidang = Input::get('bidang');
            $user->id_jabatan = Input::get('jabatan');
                       

            $user->save();

            if(Input::get('jabatan')==1){
                $dosen = new Dosen;
                $dosen->user_id=$user->id;
                $dosen->nama=Input::get('username');
                $dosen->iddosen=Input::get('idpkl');
                $dosen->save();
            }
            else if(Input::get('jabatan')==2){
                $korwil = new Korwil;
                $korwil->user_id=$user->id;
                $korwil->nama=Input::get('username');
                $korwil->nokorwil=Input::get('idpkl');
                $korwil->save();
            }
            else if(Input::get('jabatan')==3){
                $kortim = new Kortim;
                $kortim->user_id=$user->id;
                $kortim->nama=Input::get('username');
                $kortim->nokortim=Input::get('idpkl');
                $kortim->save();
            }
            else if(Input::get('jabatan')==4){
                $pcl = new Pcl;
                $pcl->user_id=$user->id;
                $pcl->nama=Input::get('username');
                $pcl->id=Input::get('idpkl');
                $pcl->save();
            }
            else if(Input::get('jabatan')==5){

            }

            Mail::send('mail/welcome', array('username'=>Input::get('username'),'password'=>Input::get('password')), function($message){
                $message->to(Input::get('email'),Input::get('username'))->subject('Welcome to WEB Monitoring PKL54!');
            });

            return Redirect::to('login')->with('success','Thanks for registering!');
        }

        // Something went wrong.
        return Redirect::to('register')->withErrors($validator)->withInput(Input::except('password'));
    }



	public function showLogin()
    {
        // Check if we already logged in
        if (Auth::check())
        {
            // Redirect to homepage
            return Redirect::to('');
        }

        // Show the login page
        return View::make('monitoring/login');
    }

    public function postLogin()
    {
        // Get all the inputs
        // id is used for login, username is used for validation to return correct error-strings
        $userdata = array(
            'username' => Input::get('username'),
            'password' => Input::get('password')
        );

        // Declare the rules for the form validation.
        $rules = array(
            'username'  => 'Required',
            'password'  => 'Required'
        );

        // Validate the inputs.
        $validator = Validator::make($userdata, $rules);

        // Check if the form validates with success.
        if ($validator->passes())
        {
            // Try to log the user in.
            if (Auth::attempt($userdata))
            {
                // Redirect to homepage
                return Redirect::to('');
            }
            else
            {
                // Redirect to the login page.
                return Redirect::to('login')->withErrors(array('password' => 'Password invalid'))->withInput(Input::except('password'));
            }
        }

        // Something went wrong.
        return Redirect::to('login')->withErrors($validator)->withInput(Input::except('password'));
    }

    public function getLogout()
    {
        // Log out
        Auth::logout();

        // Redirect to homepage
        return Redirect::to('')->with('success', 'You are logged out');
    }


    public function showKorlap()
    {
        if(Input::get('name')!==null){
            $q = Input::get('name');
            $data['count'] = count(Korlap::where('namakorlap','like','%'.$q.'%')->get());
            $data['kor'] = Korlap::where('namakorlap','like','%'.$q.'%')->paginate(12);
            $data['title']='Korlap';
            return View::make('monitoring/korsearch')->with('data',$data);
        }
        else{
            $data['kor'] = Korlap::paginate(12);
            $data['title']='Koordinator Lapangan';
            return View::make('monitoring/kor')->with('data',$data);
        }
        
    }

    public function showKorwil()
    {
        if(Input::get('name')!==null){
            $q = Input::get('name');
            $data['count'] = count(Korwil::where('namakorwil','like','%'.$q.'%')->get());
            $data['kor'] = Korwil::where('namakorwil','like','%'.$q.'%')->paginate(12);
            $data['title']='Korwil';
            return View::make('monitoring/korsearch')->with('data',$data);
        }
        else{
            $data['kor'] = Korwil::paginate(12);
            $data['title']='Koordinator Wilayah';
            return View::make('monitoring/kor')->with('data',$data);
        }
        
    }

    public function showKortim(){

        if(Input::get('name')!==null){
            $q = Input::get('name');
            $data['count'] = count(Kortim::where('namakortim','like','%'.$q.'%')->get());
            $data['kor'] = Kortim::where('namakortim','like','%'.$q.'%')->paginate(12);
            $data['title']='Kortim';
            return View::make('monitoring/korsearch')->with('data',$data);
        }
        else{
            $data['kor'] = Kortim::paginate(12);
            $data['title']='Koordinator Tim';
            
            return View::make('monitoring/kor')->with('data',$data);
        }
    }

    public function showDosen(){
        if(Input::get('name')!==null){
            $q = Input::get('name');
            $data['count'] = count(Dosen::where('namadosen','like','%'.$q.'%')->get());
            $data['kor'] = Dosen::where('namadosen','like','%'.$q.'%')->paginate(12);
            $data['title']='Dosen';
            return View::make('monitoring/korsearch')->with('data',$data);
        }
        else{
            $data['kor'] = Dosen::paginate(12);
            $data['title']='Tim Dosen';
            
            return View::make('monitoring/kor')->with('data',$data);
        }
    }
    public function showMyProfile(){
        return Redirect::to('profile='.Auth::user()->id);
    }

    public function showProfile($id){

        $data['user']=User::find($id);
        
        if($data['user']->id_jabatan==1){
            
            $data['pos']=User::find($id)->dosen()->first();
            $data['jabatan']=$data['pos']['jabatan'];
            $data['id']=$data['pos']['iddosen'];
            $data['areakerjadosen'] = Areakerjadosen::where('iddosen','=',$data['pos']['iddosen'])->get();
        }
        else if($data['user']->id_jabatan==2){
            $data['jabatan']='Koordinator wilayah';
            $data['pos']=User::find($id)->korwil()->first();
            $data['id']=$data['pos']->nokorwil;
            $data['areakerja'] = Kortim::where('nokorwil','=',$data['pos']->nokorwil)->get();
        }
        else if($data['user']->id_jabatan==3){
            $data['jabatan']='Koordinator tim';
            $data['pos']=User::find($id)->kortim()->first();
            $data['id']=$data['pos']->nokortim;
            $data['areakerja'] = Pcl::where('KODEKORTIM','=',$data['pos']->nokortim)->get();
        }else if($data['user']->id_jabatan==4){
            $data['jabatan']='Pencacah Lapangan';
            $data['pos']=User::find($id)->pcl()->first();
            $data['id']=$data['pos']->id;
        }else if($data['user']->id_jabatan==5){
            $data['jabatan']='Koordinator Lapangan';
            $data['pos']=User::find($id)->korlap()->first();
            $data['id']=$data['pos']->id;
        }

        return View::make('users/profile')->with('data',$data);        
    }

    

    public function updateProfile(){

         // Get all the inputs
        // id is used for login, username is used for validation to return correct error-strings
        $userdata = array(
            'namabaru' => Input::get('namabaru'),
            'avatar' => Input::file('avatar'),
            'description' => Input::get('description'),
            'alamat' => Input::get('alamat'),
            'daerah' => Input::get('daerah'),
            'kerabat' => Input::get('kerabat'),
            'twitter' => Input::get('twitter')
        );

        // Declare the rules for the form validation.
        $rules = array(
            //'email' => 'Required|email',
            'namabaru' => 'Required|between:3,200',
            'avatar' => 'image|max:3000',
            'kerabat' => 'digits_between:12,13',
            'Asal Daerah'  => 'alpha'
        );

        // Validate the inputs.
        $validator = Validator::make($userdata, $rules);

        if ($validator->passes()){
            $user = Auth::user();
            if(Input::file('avatar')!=null){
                $destinationPath = 'assets/image/';
                $file = Input::file('avatar');
                $extension = Input::file('avatar')->getClientOriginalExtension();
                $filename = sha1(time().time()).".{$extension}";

                $upload_success = Input::file('avatar')->move($destinationPath, $filename);
                if($upload_success){
                    File::delete($user->image);
                    $user->image = $destinationPath.'/'.$filename;
                }
            }
            if($user->id_jabatan==1){
                
                $dosen = Dosen::where('user_id','=',$user->id)->first();
                $dosen->namadosen = Input::get('namabaru'); 
                $dosen->save();
            }
            else if($user->id_jabatan==2){
                $korwil = Korwil::where('user_id','=',$user->id)->first();
                $korwil->namakorwil = Input::get('namabaru'); 
                $korwil->save();
            }
            else if($user->id_jabatan==3){
                $kortim = Kortim::where('user_id','=',$user->id)->first();
                $kortim->namakortim = Input::get('namabaru'); 
                $kortim->save();   
            }
            else if($user->id_jabatan==4){
                
            }
            else if($user->id_jabatan==5){
                $korlap = Korlap::where('user_id','=',$user->id)->first();
                $korlap->namakorlap = Input::get('namabaru'); 
                $korlap->save(); 
            }

            if(Input::get('description')!=null)
            $user->description = Input::get('description');
            if(Input::get('alamat')!=null)
            $user->alamat = Input::get('alamat');
            if(Input::get('daerah')!=null)
            $user->daerah=Input::get('daerah');
            if(Input::get('kerabat')!=null)
            $user->kerabat=Input::get('kerabat');
            if(Input::get('twitter')!=null)
            $user->twitter=Input::get('twitter');
            $user->save();
            return Redirect::to('profile='.Auth::user()->id)->with('success','Profile anda telah berhasil diupdate!');            
        }

        return Redirect::to('profile='.Auth::user()->id)->with('failed','Terjadi Kesalahan, Profile anda tidak berhasil diupdate!');
    }

    public function indexTabulasi(){
             
        $data['cirebon']['laki-laki'] = count(B1::get());
        //$data['cirebon']['perempuan'] = count(B1::where('b1r2','=','9')->get());
        return View::make('tabulasi/index')->with('data',$data);  
    }
}