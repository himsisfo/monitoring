@extends('layouts.template')

@section('title')
@parent
:: Home
@stop

@section('content')
<?php 
$c=count($data['usaha']); 
$d=count($data['pekerja']);
$e=round($c/5000); 
?>

        <section id="main-content">
          <section class="wrapper site-min-height">
            <br>
            <h3><i class="fa fa-angle-right"></i>Selamat datang di website monitoring PKL 54!</h3>
            <div class="row mt">
              <div class="col-lg-12">


                           <!-- CHART PANELS -->
                      <div class="row">
                        <div class="col-md-4 col-sm-4 mb">
                          <div class="grey-panel pn donut-chart">
                            <div class="grey-header">
                               <h5>Progress Listing</h5>
                            </div>
                            <canvas id="serverstatus01" height="120" width="120"></canvas>
                            <script>
                              var doughnutData = [
                                  {
                                    value: 70,
                                    color:"#FF6B6B"
                                  },
                                  {
                                    value : 30,
                                    color : "#fdfdfd"
                                  }
                                ];
                                var myDoughnut = new Chart(document.getElementById("serverstatus01").getContext("2d")).Doughnut(doughnutData);
                            </script>
                            <h3>80% Data Masuk</h3>
                          </div><! --/grey-panel -->
                        </div><!-- /col-md-4-->

                        <div class="col-md-8 col-sm-8 mb">
                          <div class="grey-panel pn donut-chart">
                            <div class="grey-header">
                               <h5>Progress Listing</h5>
                            </div>
                            <canvas id="serverstatus011" height="120" width="120"></canvas>
                            <script>
                              var doughnutData = [
                                  {
                                    value: 70,
                                    color:"#FF6B6B"
                                  },
                                  {
                                    value : 30,
                                    color : "#fdfdfd"
                                  }
                                ];
                                var myDoughnut = new Chart(document.getElementById("serverstatus011").getContext("2d")).Doughnut(doughnutData);
                            </script>
                            <h3>80% Data Masuk</h3>
                          </div><! --/grey-panel -->
                        </div><!-- /col-md-4-->

                      
                                    

                          <div class="col-md-8 col-sm-8 mb">
                            <div class="darkblue-panel pn">
                              <div class="darkblue-header">
                                <h5>DROPBOX STATICS</h5>
                                        </div>
                            <canvas id="serverstatus02" height="120" width="120"></canvas>
                            <script>
                              var doughnutData = [
                                  {
                                    value: 60,
                                    color:"#1c9ca7"
                                  },
                                  {
                                    value : 40,
                                    color : "#f68275"
                                  }
                                ];
                                var myDoughnut = new Chart(document.getElementById("serverstatus02").getContext("2d")).Doughnut(doughnutData);
                            </script>

                            <canvas id="serverstatus03" height="120" width="120"></canvas>
                            <script>
                              var doughnutData = [
                                  {
                                    value: 60,
                                    color:"#1c9ca7"
                                  },
                                  {
                                    value : 40,
                                    color : "#f68275"
                                  }
                                ];
                                var myDoughnut = new Chart(document.getElementById("serverstatus03").getContext("2d")).Doughnut(doughnutData);
                            </script>

                            <p>April 17, 2014</p>
                            <footer>
                              <div class="pull-left">
                                <h5><i class="fa fa-hdd-o"></i> 17 GB</h5>
                              </div>
                              <div class="pull-right">
                                <h5>60% Used</h5>
                              </div>
                            </footer>
                                      </div><! -- /darkblue panel -->
                                    </div><!-- /col-md-4 -->

                                    <div class="col-md-4 col-sm-4 mb">
                            <div class="green-panel pn">
                              <div class="green-header">
                                <h5>DISK SPACE</h5>
                              </div>
                            <canvas id="serverstatus04" height="120" width="120"></canvas>
                            <script>
                              var doughnutData = [
                                  {
                                    value: 60,
                                    color:"#2b2b2b"
                                  },
                                  {
                                    value : 40,
                                    color : "#fffffd"
                                  }
                                ];
                                var myDoughnut = new Chart(document.getElementById("serverstatus04").getContext("2d")).Doughnut(doughnutData);
                            </script>
                            <h3>60% USED</h3>
                            </div>
                          </div><! --/col-md-4 -->
                    </div><!-- /END CHART - 4TH ROW OF PANELS -->

                    <div class="col-md-13 col-sm-13 mb">
                      <div class="content-panel">
                          <div id="highchartnih" style="height: 300px"></div>
                            <script>
                                $(function () {
                                $('#highchartnih').highcharts({
                                    chart: {
                                        type: 'bar'
                                    },
                                    title: {
                                        text: 'Progress Listing'
                                    },
                                    xAxis: {
                                        categories: ['Cirebon', 'Sukabumi']
                                    },
                                    yAxis: {
                                        title: {
                                            text: 'Fruit eaten'
                                        }
                                    },
                                    series: [{
                                        name: 'Beban',
                                        data: [10, 7]
                                    }, {
                                        name: 'Hasil',
                                        data: [5, 7]
                                    }],
                                });
                            });
                            </script>
                      </div>
                    </div>

                    <div class="col-md-13 col-sm-13 mb">
                      <div class="content-panel">
                          <div id="highchartnih2" style="height: 300px"></div>
                            <script>
                                $(function () {
                                $('#highchartnih2').highcharts({
                                    chart: {
                                        type: 'bar'
                                    },
                                    title: {
                                        text: 'Progress Pencacahan'
                                    },
                                    xAxis: {
                                        categories: ['Cirebon', 'Sukabumi']
                                    },
                                    yAxis: {
                                        title: {
                                            text: 'Fruit eaten'
                                        }
                                    },
                                    series: [{
                                        name: 'Beban',
                                        data: [101, 50]
                                    }, {
                                        name: 'Hasil',
                                        data: [92, 41]
                                    }],
                                });
                            });
                            </script>
                      </div>
                    </div>

              </div>
            </div>
      
          </section><! --/wrapper -->
        </section>
@stop

