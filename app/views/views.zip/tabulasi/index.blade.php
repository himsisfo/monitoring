@extends('layouts.template')

@section('title')
@parent
:: Home
@stop

@section('content')


        <section id="main-content">
          <section class="wrapper site-min-height">
            <br>
            <h3><i class="fa fa-angle-right"></i>Menu Tabulasi</h3>


            <div id="accordion" class="panel-group">
              <div class="panel panel-default">
                  <div class="panel-heading">
                      <h4 class="panel-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Tabel 1.1.1 Jumlah Pemilik  Usaha Rumah Tangga Perikanan Tangkap Laut Menurut Jenis Kelamin di Kabupaten Cirebon dan Kabupaten Sukabumi Provinsi Jawa Barat Bulan Maret Tahun 2015
</a>
                      </h4>
                  </div>
                  <div id="collapseOne" class="panel-collapse collapse in">
                      <div class="panel-body">
                          <section id="unseen">
                                      <table class="table table-hover table-bordered table-striped table-condensed">
                                        <thead>
                                        <tr>
                                            <th  class="text-center" rowspan="2">Jenis Kelamin</th>
                                            <th  class="text-center" colspan="2">Kabupaten</th>
                                            <th  class="text-center" class="numeric" rowspan="2">Jumlah</th>
                                            
                                        </tr>
                                        <tr>
                                            <th class="text-center">Cirebon</th>
                                            <th class="text-center">Sukabumi</th>
                                        </tr>
                                       
                                        </thead>
                                        <tbody class="text-center">
                                          <tr>
                                            <td>(1)</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>Laki-Laki</td>
                                            <td>{{$data['cirebon']['laki-laki']}}</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>Perempuan</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                           <tr style="font-type:bold">
                                            <td>Jumlah</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                        </tbody>
                                    </table>
                                  </section>
                      </div>
                  </div>
              </div>
              <div class="panel panel-default">
                  <div class="panel-heading">
                      <h4 class="panel-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">Tabel 1.2.1 Jumlah Pemilik  Usaha Rumah Tangga Perikanan Tangkap Laut MenurutKelompok Umur di Kabupaten Cirebon dan Kabupaten Sukabumi ProvinsiJawa Barat Bulan Maret Tahun 2015</a>
                      </h4>
                  </div>
                  <div id="collapseTwo" class="panel-collapse collapse">
                      <div class="panel-body">
                              <section id="unseen">
                                      <table class="table table-hover table-bordered table-striped table-condensed">
                                        <thead>
                                        <tr>
                                            <th  class="text-center" rowspan="2">Kelompok Umur</th>
                                            <th  class="text-center" colspan="2">Kabupaten</th>
                                            <th  class="text-center" class="numeric" rowspan="2">Jumlah</th>
                                            
                                        </tr>
                                        <tr>
                                            <th class="text-center">Cirebon</th>
                                            <th class="text-center">Sukabumi</th>
                                        </tr>
                                       
                                        </thead>
                                        <tbody class="text-center">
                                          <tr>
                                            <td>(1)</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>15-19</td>
                                            <td>{{$data['cirebon']['laki-laki']}}</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>20-24</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>25-29</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>30-34</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>35-39</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>40-44</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>45-49</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>50-54</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>55-59</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>60+</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          
                                           <tr style="font-type:bold">
                                            <td>Jumlah</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                        </tbody>
                                    </table>
                                  </section>
                      
                      </div>
                  </div>
              </div>
              <div class="panel panel-default">
                  <div class="panel-heading">
                      <h4 class="panel-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">Tabel 1.3.1 Jumlah Pemilik  Usaha Rumah Tangga Perikanan Tangkap Laut Menurut TingkatPendidikan yang Ditamatkan di Kabupaten Cirebon dan Kabupaten SukabumiProvinsi Jawa Barat Bulan Maret Tahun 2015</a>
                      </h4>
                  </div>
                  <div id="collapseThree" class="panel-collapse collapse">
                      <div class="panel-body">
                        <section id="unseen">
                                      <table class="table table-hover table-bordered table-striped table-condensed">
                                        <thead>
                                        <tr>
                                            <th  class="text-center" rowspan="2">Tingkat Pendidikan</th>
                                            <th  class="text-center" colspan="2">Kabupaten</th>
                                            <th  class="text-center" class="numeric" rowspan="2">Jumlah</th>
                                            
                                        </tr>
                                        <tr>
                                            <th class="text-center">Cirebon</th>
                                            <th class="text-center">Sukabumi</th>
                                        </tr>
                                       
                                        </thead>
                                        <tbody class="text-center">
                                          <tr>
                                            <td>(1)</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>Tidak/Belum Pernah Sekolah</td>
                                            <td>{{$data['cirebon']['laki-laki']}}</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>Tidak/Belum Tamat SD</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>SD</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>SLTP</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>SLTA (Umum)</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>SLTA (Kejuruan)</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>DiplomaI/II/III/Akademi</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          <tr>
                                            <td>Universitas</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                          
                                           <tr style="font-type:bold">
                                            <td>Jumlah</td>
                                            <td>(2)</td>
                                            <td>(3)</td>
                                            <td>(4)</td>
                                          </tr>
                                        </tbody>
                                    </table>
                                  </section>
                      </div>
                  </div>
              </div>
          </div>




          </section><! --/wrapper -->
        </section>
@stop

