@extends('layouts.template')

@section('title')
@parent
:: Game
@stop


@section('content')

<section id="main-content">
    <section class="wrapper site-min-height text-center">
		<iframe width="620" height="438" src="http://www.playmycode.com/play/embed/krakatomato/asteroids" marginheight="0" marginwidth="0" scrolling="no" frameborder="0" style="border: none; border-size: 0; overflow: hidden; overflow-x: hidden; overflow-y: hidden;"></iframe>
	</section>
</section>	
@stop