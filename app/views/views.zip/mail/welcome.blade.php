<h1>Hi, {{ $username }}!</h1>
 
<p>We'd like to personally welcome you to the <a href="monitoring.pkl.stis.ac.id">WEB Monitoring PKL54</a>. Thank you for registering!.</p>
