<?php

class B3 extends Eloquent {

    protected $connection = 'mysqlcapi';
    protected $table = 'b3';
	protected $primaryKey = 'nks';

}