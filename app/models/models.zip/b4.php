<?php

class B4 extends Eloquent {

    protected $connection = 'mysqlcapi';
    protected $table = 'b4';
	protected $primaryKey = 'nkskapal';

}