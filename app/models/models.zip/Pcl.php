<?php
class Pcl extends Eloquent {
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	
	protected $table = 'pcl';
	protected $primaryKey = 'KODEPCL';
	
}