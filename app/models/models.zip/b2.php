<?php

class B2 extends Eloquent {

    protected $connection = 'mysqlcapi';
    protected $table = 'b2';
	protected $primaryKey = 'nks';
}