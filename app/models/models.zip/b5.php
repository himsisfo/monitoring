<?php

class B5 extends Eloquent {

    protected $connection = 'mysqlcapi';
    protected $table = 'b5';
	protected $primaryKey = 'nks';

}