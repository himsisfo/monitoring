<?php

class B6 extends Eloquent {

    protected $connection = 'mysqlcapi';
    protected $table = 'b6';
	protected $primaryKey = 'nks';

}