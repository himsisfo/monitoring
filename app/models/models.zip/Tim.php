<?php
class Tim extends Eloquent {
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */

	protected $primaryKey = 'KODETIM';
	protected $table = 'tim';
	

}